package com.mycompany.login;

import java.awt.HeadlessException;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Login {

  public boolean checkUserName(String userName) {
    boolean underscore = false;

    for (int i = 0; i < userName.length(); i++) {
      if ('_' == userName.charAt(i)) {
        underscore = true;
      }
    }

    if (underscore == true && userName.length() <= 5) {
      return true;
    } else {
      return false;
    }
  }

  public boolean checkPassWordComplexity(String password) {
    boolean cap = false;
    boolean number = false;
    boolean specialChar = false;

    for (int i = 0; i < password.length(); i++) {
      if ((int) password.charAt(i) >= 65 && (int) password.charAt(i) <= 90) {
        cap = true;
      }

      if ((int) password.charAt(i) >= 48 && (int) password.charAt(i) <= 57) {
        number = true;
      }

      if (((int) password.charAt(i) >= 33 && (int) password.charAt(i) <= 47)
          || ((int) password.charAt(i) >= 58 && (int) password.charAt(i) <= 64)) {
        specialChar = true;
      }
    }

    if (cap == true && number == true && specialChar == true && password.length() >= 8) {
      return true;
    } else {
      return false;
    }
  }

  public String registerUser(String username, String password) {
    if (checkUserName(username) == false && checkPassWordComplexity(password) == true) {
      return "The username is incorrectly formatted";
    } else if (checkPassWordComplexity(password) == false && checkUserName(username) == true) {
      return "The password does not meet the complexity requirements.";
    } else {
      return "The two above conditions did not meet, the user is not registered successfully.";
    }
  }

  public boolean loginUser(String username, String password, String loginUsername, String loginPassword) {
    if (username.equals(loginUsername) && password.equals(loginPassword)) {
      return true;
    } else {
      return false;
    }
  }

  public String returnLoginStatus(String first, String last, String username, String password, String loginUsername,
      String loginPassword) {
    if (loginUser(username, password, loginUsername, loginPassword) == true) {
      return "Welcome " + first + " " + last + " it is great to see you again";
    } else {
      return "Username or password incorrect, please try again";
    }
  }

  public static void main(String[] args) {
    Login status = new Login();
    Task task = new Task();

    try (Scanner input = new Scanner(System.in)) {
      String firstName = JOptionPane.showInputDialog(null, "Enter your first name:");
      String lastName = JOptionPane.showInputDialog(null, "Enter your last name");
      String regUsername = JOptionPane.showInputDialog(null,
          "Enter Username:");
      String regPassword = JOptionPane.showInputDialog(null,
          "Enter Password.\n" +
          "1= At least 8 characters long\r\n" +
          "2= Contain a capital letter\r\n" +
          "3= Contain a number\r\n" +
          "4= Contain a special character");

      boolean reg = false;

      while (reg == false) {
        if (status.checkUserName(regUsername) == true && status.checkPassWordComplexity(regPassword) == true) {
          System.out.println(status.registerUser(regUsername, regPassword));
          reg = true;
          JOptionPane.showMessageDialog(null, "Username and Password successfully captured.");
 
        } else if (status.checkUserName(regUsername) == false && status.checkPassWordComplexity(regPassword) == true) {
          System.out.println(status.registerUser(regUsername, regPassword));
          regUsername = JOptionPane.showInputDialog("\t\t\"Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length");
        } else if (status.checkUserName(regUsername) == true && status.checkPassWordComplexity(regPassword) == false) {
          JOptionPane.showMessageDialog(null, status.registerUser(regUsername, regPassword));
          regPassword = JOptionPane.showInputDialog("\t\tPassword is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        } else {
          JOptionPane.showMessageDialog(null, status.registerUser(regUsername, regPassword));
          regUsername = JOptionPane.showInputDialog("\t\tUsername entered did not meet condition \n + Enter Username again");
          regPassword = JOptionPane.showInputDialog("\t\tPassword entered did not meet condition \\n + Enter Password again");
        }
      }

      String logUsername = JOptionPane.showInputDialog("\t\tLog in page \n Please enter your Username to login");
      String logPassword = JOptionPane.showInputDialog("\t\tPlease enter your Password to login");

      boolean log = false;
      int count = 0;
      int choose;

      try (Scanner sc = new Scanner(System.in)) {
        while (!log) {
          if (regUsername.equals(logUsername) && regPassword.equals(logPassword)) {
            System.out.println(status.returnLoginStatus(firstName, lastName, regUsername, regPassword, logUsername, logPassword));
            log = true;
          } else if (!(regUsername.equals(logUsername)) && regPassword.equals(logPassword)) {
            System.out.println(status.returnLoginStatus(firstName, lastName, regUsername, regPassword, logUsername, logPassword));
            logUsername = JOptionPane.showInputDialog("\t\tYour username is not matching, please enter your correct username to login");
          } else if (!(regPassword.equals(logPassword)) && regUsername.equals(logUsername)) {
            System.out.println(status.returnLoginStatus(firstName, lastName, regUsername, regPassword, logUsername, logPassword));
            logPassword = JOptionPane.showInputDialog("\t\tYour password is not matching, please enter your correct password to login");
          } else {
            System.out.println(status.returnLoginStatus(firstName, lastName, regUsername, regPassword, logUsername, logPassword));
            System.out.println("");
            logUsername = JOptionPane.showInputDialog("\t\tYour username is not matching, please enter your correct username to login");
            logPassword = JOptionPane.showInputDialog("\t\tYour password is not matching, please enter your correct password to login");
          }

          count++;

          if (count == 3) {
            System.out.println("Your account is blocked");
            break;
          }
        }

        if (regUsername.equals(logUsername) && regPassword.equals(logPassword)) {
          choose = Integer.parseInt(JOptionPane.showInputDialog(null,
              "Welcome to EasyKanBan \nPlease choose one of the following \n a. Option 1) Add tasks \n b. Option 2) Show-report \n c. Option 3) Quit"));

          while (choose != 3) {
            if (choose == 1) {
              String value = JOptionPane.showInputDialog("How many tasks do you want to add");
              int taskNumber = Integer.parseInt(value);
              String devName;
              String devSurname;
              int taskDuration1;
              int taskCount;
              String taskStatus;

              for (int i = 0; i < taskNumber; i++) {
                taskCount = i;
                String taskDescription = JOptionPane.showInputDialog("\t\tPlease enter the Task Description:");
                String taskName = JOptionPane.showInputDialog("\t\tPlease enter the Task Name:");
                boolean s = task.checkTaskDescription(taskDescription);

                if (!s) {
                  JOptionPane.showMessageDialog(null, "Your task description has more than 50 characters");
                }

                devName = JOptionPane.showInputDialog(null, "Please enter the Developer Name:");
                devSurname = JOptionPane.showInputDialog(null, "Please enter the Developer Surname:");
                String val = JOptionPane.showInputDialog("How many tasks do you want to add");
                int taskDuration = Integer.parseInt(val);
                //Task ID
                String taskID = task.createTaskID(taskName, taskNumber, devName);
                String vap = JOptionPane.showInputDialog("Please choose the task status: \n a. Option 1) To Do \n b. Option 2) Done \n c. Option 3) Doing");
                int status1 = Integer.parseInt(vap);

                if (status1 == 1) {
                  taskStatus = "To Do";
                } else if (status1 == 2) {
                  taskStatus = "Done";
                } else {
                  taskStatus = "Doing";
                }

                JOptionPane.showMessageDialog(null, task.printTaskDetails(taskStatus, devName, devSurname, taskNumber, taskName, taskDescription, taskID, taskDuration));
              }

              JOptionPane.showMessageDialog(null, "The total hours \n" + task.returnTotalHours(0));
            } else if (choose == 2) {
              JOptionPane.showMessageDialog(null, "Coming Soon");
            } else {
              JOptionPane.showMessageDialog(null, "Invalid option. Please choose again.");
            }

            choose = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Welcome to EasyKanBan \nPlease choose one of the following \n a. Option 1) Add tasks \n b. Option 2) Show-report \n c. Option 3) Quit"));
          }
        }
      }
    }
  }
}
