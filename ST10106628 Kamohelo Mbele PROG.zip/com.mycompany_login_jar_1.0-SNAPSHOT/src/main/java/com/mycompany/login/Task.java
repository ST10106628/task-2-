package com.mycompany.login;
import javax.swing.JOptionPane;
public class Task {
    int total=0;
     public boolean checkTaskDescription(String taskDescription){
        
        if(taskDescription.length()>50){
            return false;
        }
        
        
        return true;
    }
    public String createTaskID(String taskName, int taskNumber, String devName){
         String taskID=taskName.substring(0,2)+" : "+taskNumber+" : "+devName.substring(devName.length()-3);
        
        return taskID;
    }
     public String printTaskDetails(String taskStatus, String devName, String devSurname, int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration){
       
         JOptionPane.showMessageDialog(null,"Task Status \t "+taskStatus+" \n Developer Details \t" +devName+" \t "+devSurname+"\n Duration \t"+taskDuration);
        return "";
    }
     public int returnTotalHours(int hours){
         total+=hours;
        return total;
    }
    
}

